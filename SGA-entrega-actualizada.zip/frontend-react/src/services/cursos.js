import API_URL from "../config/api"

const URL_CURSOS = `${API_URL}/cursos`

// Centraliza las peticiones del módulo y sus errores.
async function solicitarCurso(token, { codigo, method = "GET", datos, signal } = {}) {
    const url = codigo ? `${URL_CURSOS}/${encodeURIComponent(codigo)}` : URL_CURSOS
    const respuesta = await fetch(url, {
        method,
        signal,
        headers: {
            Authorization: `Bearer ${token}`,
            ...(datos && { "Content-Type": "application/json" })
        },
        ...(datos && { body: JSON.stringify(datos) })
    })
    const resultado = await respuesta.json()
    if (!respuesta.ok) throw new Error(resultado.mensaje || "No se pudo completar la operación")
    return resultado
}

export function listarCursos(token, signal) {
    return solicitarCurso(token, { signal })
}

export function guardarCurso(token, datos, codigoOriginal) {
    return solicitarCurso(token, {
        codigo: codigoOriginal,
        method: codigoOriginal ? "PUT" : "POST",
        datos
    })
}

export function eliminarCurso(token, codigo) {
    return solicitarCurso(token, { codigo, method: "DELETE" })
}
