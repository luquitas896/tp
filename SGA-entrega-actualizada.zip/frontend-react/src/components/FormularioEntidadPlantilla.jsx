import { useState } from "react"
import Alert from "@mui/material/Alert"
import API_URL from "../config/api"
import { useAuth } from "../context/useAuth"
import "./FormularioEntidadPlantilla.css"

const API_ENTIDADES = `${API_URL}/entidades`
{/*parte visual y envía pedidos al backend.*/}
export default function FormularioEntidadPlantilla({ entidadEditar, onEntidadGuardada, onCancelar }) {
    const { token } = useAuth()
    const [formulario, setFormulario] = useState({
        codigo: entidadEditar?.codigo ?? "",
        nombre: entidadEditar?.nombre ?? "",
        descripcion: entidadEditar?.descripcion ?? ""
    })
    const [error, setError] = useState("")
    const [guardando, setGuardando] = useState(false)

    function manejarCambio(e) {
        const { name, value } = e.target
        const valor = name === "codigo" ? value.replace(/\s/g, "") : value
        setFormulario(actual => ({ ...actual, [name]: valor }))
        setError("")
    }

    async function guardar(e) {
        e.preventDefault()
        setError("")

        const codigo = formulario.codigo.trim()
        if (!codigo) {
            setError("El código es obligatorio.")
            return
        }
        if (/\s/.test(formulario.codigo)) {
            setError("El código no puede contener espacios.")
            return
        }
        if (!formulario.nombre.trim()) {
            setError("El nombre es obligatorio.")
            return
        }

        setGuardando(true)

        const editando = Boolean(entidadEditar)
        const url = editando
            ? `${API_ENTIDADES}/${encodeURIComponent(entidadEditar.codigo)}`
            : API_ENTIDADES

        try {
            const respuesta = await fetch(url, {
                method: editando ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({ ...formulario, codigo })
            })
            const datos = await respuesta.json()
            if (!respuesta.ok) throw new Error(datos.mensaje || "No se pudo guardar el registro")
            onEntidadGuardada(editando ? "Se actualizó correctamente." : "Se agregó correctamente.")
        } catch (error) {
            setError(error.message || "No se pudo conectar con el servidor")
        } finally {
            setGuardando(false)
        }
    }

    return (
        <section className="formulario-entidad">
            <h2 className="formulario-entidad__titulo">
                {entidadEditar ? "Editar registro" : "Nuevo registro"}
            </h2>
            <form className="formulario-entidad__form" onSubmit={guardar} noValidate>
                <label className="formulario-entidad__campo">
                    Código *
                    <input
                        name="codigo"
                        value={formulario.codigo}
                        onChange={manejarCambio}
                        onKeyDown={e => {
                            if (e.key === " " || e.code === "Space") e.preventDefault()
                        }}
                        required
                    />
                </label>
                <label className="formulario-entidad__campo">
                    Nombre
                    <input name="nombre" value={formulario.nombre} onChange={manejarCambio} required />
                </label>
                <label className="formulario-entidad__campo">
                    Descripción
                    <input name="descripcion" value={formulario.descripcion} onChange={manejarCambio} />
                </label>
                <div className="formulario-entidad__acciones">
                    <button className="formulario-entidad__boton" type="submit" disabled={guardando}>
                        {guardando ? "Guardando…" : "Guardar"}
                    </button>
                    {entidadEditar && (
                        <button
                            className="formulario-entidad__boton formulario-entidad__boton--secundario"
                            type="button"
                            onClick={onCancelar}
                            disabled={guardando}
                        >
                            Cancelar
                        </button>
                    )}
                </div>
                {error && <Alert severity="error" role="alert" sx={{ gridColumn: "1 / -1" }}>{error}</Alert>}
            </form>
        </section>
    )
}
