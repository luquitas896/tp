import { useState } from "react"
import { Alert, Box, Button, MenuItem, Paper, TextField, Typography } from "@mui/material"
import API_URL from "../config/api"
import { useAuth } from "../context/useAuth"

const API_MATERIAS = `${API_URL}/materias`

function formularioInicial(materia) {
    return {
        codigo: materia?.codigo ?? "",
        nombre: materia?.nombre ?? "",
        descripcion: materia?.descripcion ?? "",
        cargaHoraria: materia?.cargaHoraria ?? "",
        estado: materia?.estado ?? "activa"
    }
}

export default function FormularioMateria({ materiaEditar, onMateriaGuardada, onCancelar }) {
    const { token } = useAuth()
    const [formulario, setFormulario] = useState(() => formularioInicial(materiaEditar))
    const [error, setError] = useState("")
    const [guardando, setGuardando] = useState(false)

    function manejarCambio(evento) {
        const { name, value } = evento.target
        setFormulario(actual => ({ ...actual, [name]: value }))
        setError("")
    }

    async function guardar(evento) {
        evento.preventDefault()
        setError("")

        const materia = {
            codigo: formulario.codigo.trim().toUpperCase(),
            nombre: formulario.nombre.trim(),
            descripcion: formulario.descripcion.trim(),
            cargaHoraria: Number(formulario.cargaHoraria),
            estado: formulario.estado
        }

        if (!materia.codigo || !materia.nombre) {
            setError("Completá el código y el nombre.")
            return
        }
        if (!Number.isInteger(materia.cargaHoraria) || materia.cargaHoraria <= 0) {
            setError("La carga horaria debe ser un número entero mayor que cero.")
            return
        }
        if (formulario.descripcion.length > 0 && !formulario.descripcion.trim()) {
            setError("La descripción no puede contener únicamente espacios.")
            return
        }

        const editando = Boolean(materiaEditar)
        const codigoUrl = editando ? materiaEditar.codigo : materia.codigo
        setGuardando(true)
        try {
            const respuesta = await fetch(
                editando ? `${API_MATERIAS}/${encodeURIComponent(codigoUrl)}` : API_MATERIAS,
                {
                    method: editando ? "PUT" : "POST",
                    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                    body: JSON.stringify(materia)
                }
            )
            const datos = await respuesta.json().catch(() => ({}))
            if (!respuesta.ok) {
                throw new Error(datos.mensaje || `No se pudo guardar la materia (HTTP ${respuesta.status}).`)
            }

            setFormulario(formularioInicial(null))
            onMateriaGuardada(editando ? "Materia modificada correctamente." : "Materia registrada correctamente.")
        } catch (error) {
            setError(error.message || "No se pudo conectar con el servidor.")
        } finally {
            setGuardando(false)
        }
    }

    return (
        <Paper component="section" elevation={0} sx={{ p: { xs: 2.5, sm: 3.5 }, mb: 3, border: 1, borderColor: "divider", borderRadius: 4 }}>
            <Typography component="h1" variant="h5" sx={{ mb: 2.5, fontWeight: 700 }}>
                {materiaEditar ? "Editar materia" : "Nueva materia"}
            </Typography>
            <Box component="form" onSubmit={guardar} sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "repeat(2, minmax(0, 1fr))" }, gap: 2 }}>
                <TextField name="codigo" label="Código" value={formulario.codigo} onChange={manejarCambio} required fullWidth inputProps={{ maxLength: 30 }} />
                <TextField name="nombre" label="Nombre" value={formulario.nombre} onChange={manejarCambio} required fullWidth inputProps={{ maxLength: 100 }} />
                <TextField name="cargaHoraria" label="Carga horaria" type="number" value={formulario.cargaHoraria} onChange={manejarCambio} required fullWidth inputProps={{ min: 1, step: 1 }} />
                <TextField name="estado" label="Estado" value={formulario.estado} onChange={manejarCambio} required select fullWidth>
                    <MenuItem value="activa">Activa</MenuItem>
                    <MenuItem value="inactiva">Inactiva</MenuItem>
                </TextField>
                <TextField name="descripcion" label="Descripción (opcional)" value={formulario.descripcion} onChange={manejarCambio} multiline minRows={2} fullWidth sx={{ gridColumn: { sm: "1 / -1" } }} inputProps={{ maxLength: 500 }} />
                <Box sx={{ gridColumn: "1 / -1", display: "flex", justifyContent: "flex-end", flexWrap: "wrap", gap: 1.5, mt: 1 }}>
                    <Button type="submit" variant="contained" disabled={guardando}>
                        {guardando ? "Guardando…" : materiaEditar ? "Guardar cambios" : "Registrar materia"}
                    </Button>
                    {materiaEditar && <Button type="button" onClick={onCancelar} disabled={guardando} variant="outlined">Cancelar</Button>}
                </Box>
                {error && <Alert severity="error" role="alert" sx={{ gridColumn: "1 / -1" }}>{error}</Alert>}
            </Box>
        </Paper>
    )
}
