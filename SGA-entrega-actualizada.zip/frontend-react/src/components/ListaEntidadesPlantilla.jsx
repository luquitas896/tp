
import { useEffect, useState } from "react"
import Alert from "@mui/material/Alert"
import API_URL from "../config/api"
import { useAuth } from "../context/useAuth"
import "./ListaEntidadesPlantilla.css"

const API_ENTIDADES = `${API_URL}/entidades`
{/*muestra los campos y botones, y manda los datos cuando guardás.*/}
export function ListaEntidadesPlantilla({ actualizar, onEntidadGuardada, onEditarEntidad }) {
    const { token, usuario } = useAuth()
    const [entidades, setEntidades] = useState([])
    const [error, setError] = useState("")

    useEffect(() => {
        async function cargarEntidades() {
            setError("")
            try {
                const respuesta = await fetch(API_ENTIDADES, {
                    headers: { Authorization: `Bearer ${token}` }
                })
                const datos = await respuesta.json()
                if (!respuesta.ok) throw new Error(datos.mensaje || "No se pudo cargar la lista")
                setEntidades(datos)
            } catch (error) {
                setError(error.message || "No se pudo conectar con el servidor")
            }
        }
        cargarEntidades()
    }, [actualizar, token])

    async function eliminarEntidad(codigo) {
        if (!window.confirm(`¿Estás seguro de que querés eliminar el registro ${codigo}?`)) return
        try {
            const respuesta = await fetch(`${API_ENTIDADES}/${encodeURIComponent(codigo)}`, {
                method: "DELETE",
                headers: { Authorization: `Bearer ${token}` }
            })
            const datos = await respuesta.json()
            if (!respuesta.ok) throw new Error(datos.mensaje || "No se pudo eliminar el registro")
            onEntidadGuardada("Se eliminó correctamente.")
        } catch (error) {
            setError(error.message || "No se pudo conectar con el servidor")
        }
    }

    return (
<section className="entidades">
    <h2 className="entidades__titulo">Registros</h2>

    {error && <Alert severity="error" role="alert" sx={{ mb: 2 }}>{error}</Alert>}

    {entidades.length === 0 ? (
        <p>No hay registros.</p>
    ) : (
        <ul className="entidades__lista">
            {entidades.map(entidad => (
                <li className="entidades__item" key={entidad.codigo}>
                    <strong>{entidad.nombre}</strong> ({entidad.codigo})

                    {entidad.descripcion && <p>{entidad.descripcion}</p>}

                    {usuario?.rol === "admin" && (
                        <div className="entidades__acciones">
                            <button type="button" onClick={() => onEditarEntidad(entidad)}>
                                Editar
                            </button>
                            <button type="button" onClick={() => eliminarEntidad(entidad.codigo)}>
                                Eliminar
                            </button>
                        </div>
                    )}
                </li>
            ))}
        </ul>
    )}
</section>
    )
}
