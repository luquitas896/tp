import { useEffect, useState } from "react"
import { Alert, Box, Button, CircularProgress, Card, CardActions, CardContent, Chip, Stack, Typography } from "@mui/material"
import { eliminarCurso, listarCursos } from "../services/cursos"
import { useAuth } from "../context/useAuth"

export default function ListaCursos({ version, onEditar, onEliminado }) {
    const { token, usuario } = useAuth()
    const [cursos, setCursos] = useState([])
    const [error, setError] = useState("")
    const [cargando, setCargando] = useState(true)
    const esAdmin = usuario?.rol === "admin"

    // Cancela la consulta anterior al cambiar de versión o salir de la página.
    useEffect(() => {
        const controller = new AbortController()
        async function traerCursos() {
            setError("")
            setCargando(true)
            try {
                setCursos(await listarCursos(token, controller.signal))
            } catch (err) {
                if (!controller.signal.aborted) setError(err.message)
            } finally {
                if (!controller.signal.aborted) setCargando(false)
            }
        }
        traerCursos()
        return () => controller.abort()
    }, [version, token])

    // DELETE
    async function borrar(curso) {
        if (!window.confirm(`¿Eliminar el curso "${curso.nombre}" (${curso.codigo})?`)) return

        try {
            await eliminarCurso(token, curso.codigo)
            onEliminado("Curso eliminado correctamente.")
        } catch (err) {
            setError(err.message || "No se pudo conectar con el servidor")
        }
    }

    return (
        <Box component="section" sx={{ minWidth: 0 }}>
            <Stack direction="row" sx={{ alignItems: "center", justifyContent: "space-between", mb: 2 }}>
                <Typography component="h2" variant="h5" sx={{ fontWeight: 700 }}>Listado de cursos</Typography>
                <Chip label={`${cursos.length} cursos`} color="primary" variant="outlined" />
            </Stack>
            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            {cargando ? (
                <Box role="status" sx={{ py: 5, textAlign: "center" }}><CircularProgress size={28} aria-label="Cargando cursos" /></Box>
            ) : error ? null : cursos.length === 0 ? (
                <Alert severity="info">Todavía no hay cursos registrados.</Alert>
            ) : (
                <Stack component="ul" spacing={2} sx={{ listStyle: "none", p: 0, m: 0 }}>
                    {cursos.map(curso => (
                        <Card component="li" variant="outlined" key={curso.codigo} sx={{ borderRadius: 3 }}>
                            <CardContent>
                                <Stack direction={{ xs: "column", sm: "row" }} spacing={1}
                                    sx={{ alignItems: { xs: "flex-start", sm: "center" }, mb: 1 }}>
                                    <Typography component="h3" variant="h6">{curso.nombre}</Typography>
                                    <Chip label={curso.codigo} size="small" color="primary" variant="outlined" />
                                </Stack>
                                {curso.descripcion && <Typography color="text.secondary" sx={{ mb: 1 }}>{curso.descripcion}</Typography>}
                                <Chip label={`${curso.duracion} horas`} size="small" />
                            </CardContent>
                            {esAdmin && (
                                <CardActions sx={{ px: 2, pb: 2, gap: 1 }}>
                                    <Button variant="outlined" onClick={() => onEditar(curso)}>Editar</Button>
                                    <Button variant="outlined" color="error" onClick={() => borrar(curso)}>Eliminar</Button>
                                </CardActions>
                            )}
                        </Card>
                    ))}
                </Stack>
            )}
        </Box>
    )
}
