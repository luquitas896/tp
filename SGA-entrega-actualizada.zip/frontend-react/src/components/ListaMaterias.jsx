import { useEffect, useState } from "react"
import { Alert, Box, Button, Chip, Paper, Stack, Typography } from "@mui/material"
import API_URL from "../config/api"
import { useAuth } from "../context/useAuth"

const API_MATERIAS = `${API_URL}/materias`

export function ListaMaterias({ actualizar, onMateriaGuardada, onEditarMateria }) {
    const { token, usuario } = useAuth()
    const [materias, setMaterias] = useState([])
    const [cargando, setCargando] = useState(true)
    const [error, setError] = useState("")

    useEffect(() => {
        async function cargarMaterias() {
            setCargando(true)
            setError("")
            try {
                const respuesta = await fetch(API_MATERIAS, {
                    headers: { Authorization: `Bearer ${token}` }
                })
                const datos = await respuesta.json().catch(() => ({}))
                if (!respuesta.ok) throw new Error(datos.mensaje || `No se pudo cargar la lista (HTTP ${respuesta.status}).`)
                setMaterias(datos)
            } catch (error) {
                console.error("Error al cargar materias:", error)
                setError(error.message || "No se pudo conectar con el servidor.")
            } finally {
                setCargando(false)
            }
        }
        cargarMaterias()
    }, [actualizar])

    async function eliminarMateria(codigo) {
        if (!window.confirm(`¿Querés eliminar la materia ${codigo}?`)) return
        setError("")
        try {
            const respuesta = await fetch(`${API_MATERIAS}/${encodeURIComponent(codigo)}`, {
                method: "DELETE",
                headers: { Authorization: `Bearer ${token}` }
            })
            const datos = await respuesta.json().catch(() => ({}))
            if (!respuesta.ok) throw new Error(datos.mensaje || `No se pudo eliminar (HTTP ${respuesta.status}).`)
            onMateriaGuardada("Materia eliminada correctamente.")
        } catch (error) {
            setError(error.message || "No se pudo conectar con el servidor.")
        }
    }

    if (cargando) {
        return <Paper component="section" elevation={0} sx={{ p: 3, border: 1, borderColor: "divider", borderRadius: 4 }}><Typography color="text.secondary">Cargando materias…</Typography></Paper>
    }

    return (
        <Paper component="section" elevation={0} sx={{ p: { xs: 2.5, sm: 3.5 }, border: 1, borderColor: "divider", borderRadius: 4, bgcolor: "background.paper" }}>
            <Typography component="h2" variant="h5" sx={{ mb: 2.5, fontWeight: 700 }}>Materias</Typography>
            {error && <Alert severity="error" role="alert" sx={{ mb: 2 }}>{error}</Alert>}
            {materias.length === 0 ? (
                <Typography color="text.secondary">No hay materias registradas.</Typography>
            ) : (
                <Stack component="ul" spacing={1.5} sx={{ listStyle: "none", p: 0, m: 0 }}>
                    {materias.map(materia => (
                        <Paper component="li" key={materia.codigo} elevation={0} sx={{ p: { xs: 2, sm: 2.5 }, border: 1, borderColor: "divider", borderRadius: 3, display: "flex", alignItems: { xs: "stretch", sm: "center" }, justifyContent: "space-between", flexDirection: { xs: "column", sm: "row" }, gap: 2 }}>
                            <Stack direction="row" spacing={1.5} sx={{ alignItems: "center", flexWrap: "wrap" }}>
                                <Chip label={materia.codigo} color="primary" variant="outlined" size="small" />
                                <Box>
                                    <Typography fontWeight={600}>{materia.nombre}</Typography>
                                    {materia.descripcion && <Typography variant="body2" color="text.secondary">{materia.descripcion}</Typography>}
                                    <Typography variant="body2" color="text.secondary">{materia.cargaHoraria} horas · {materia.estado}</Typography>
                                </Box>
                            </Stack>
                            {usuario?.rol === "admin" && <Stack direction="row" spacing={1} sx={{ justifyContent: "flex-end" }}>
                                <Button type="button" onClick={() => onEditarMateria(materia)} variant="outlined" size="small">Editar</Button>
                                <Button type="button" onClick={() => eliminarMateria(materia.codigo)} variant="outlined" color="error" size="small">Eliminar</Button>
                            </Stack>}
                        </Paper>
                    ))}
                </Stack>
            )}
        </Paper>
    )
}
