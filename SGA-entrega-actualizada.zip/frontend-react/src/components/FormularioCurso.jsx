import { useState } from "react"
import { Alert, Box, Button, Divider, Paper, Stack, TextField, Typography } from "@mui/material"
import { guardarCurso } from "../services/cursos"
import { useAuth } from "../context/useAuth"

export default function FormularioCurso({ curso, onGuardado, onCancelar }) {
    const { token } = useAuth()
    const editando = Boolean(curso)

    // Si hay un curso seleccionado, el formulario arranca con sus datos
    const [datos, setDatos] = useState({
        codigo: curso?.codigo ?? "",
        nombre: curso?.nombre ?? "",
        descripcion: curso?.descripcion ?? "",
        duracion: curso?.duracion ?? ""
    })
    const [error, setError] = useState("")
    const [enviando, setEnviando] = useState(false)

    function actualizarCampo(e) {
        const { name, value } = e.target
        // El código no admite espacios
        const nuevoValor = name === "codigo" ? value.replace(/\s/g, "") : value
        setDatos(previo => ({ ...previo, [name]: nuevoValor }))
        setError("")
    }

    function validar() {
        if (!datos.codigo.trim()) return "El código es obligatorio."
        if (!datos.nombre.trim()) return "El nombre es obligatorio."
        const horas = Number(datos.duracion)
        if (!datos.duracion || !Number.isInteger(horas) || horas < 1) {
            return "La duración debe ser un número entero mayor que cero."
        }
        return ""
    }

    async function enviar(e) {
        e.preventDefault()

        const problema = validar()
        if (problema) {
            setError(problema)
            return
        }

        setEnviando(true)
        setError("")

        try {
            await guardarCurso(token, {
                codigo: datos.codigo.trim(),
                nombre: datos.nombre.trim(),
                descripcion: datos.descripcion.trim(),
                duracion: Number(datos.duracion)
            }, curso?.codigo)

            onGuardado(editando ? "Curso modificado correctamente." : "Curso registrado correctamente.")
        } catch (err) {
            setError(err.message || "No se pudo conectar con el servidor")
        } finally {
            setEnviando(false)
        }
    }

    return (
        <Paper component="section" variant="outlined" sx={{ p: { xs: 2, sm: 3 }, borderRadius: 3, borderTop: 4, borderTopColor: "primary.main" }}>
            <Typography component="h2" variant="h5" sx={{ mb: 1, fontWeight: 700 }}>
                {editando ? `Editar curso ${curso.codigo}` : "Nuevo curso"}
            </Typography>
            <Typography color="text.secondary" variant="body2">Completá los datos del curso. Los campos con * son obligatorios.</Typography>
            <Divider sx={{ my: 3 }} />
            <Box component="form" onSubmit={enviar} noValidate
                sx={{ display: "grid", gridTemplateColumns: "1fr", gap: 2 }}>
                <TextField label="Código" name="codigo" required fullWidth
                    value={datos.codigo} onChange={actualizarCampo} disabled={enviando}
                    onKeyDown={e => { if (e.key === " ") e.preventDefault() }} />
                <TextField label="Nombre" name="nombre" required fullWidth
                    value={datos.nombre} onChange={actualizarCampo} disabled={enviando} />
                <TextField label="Descripción" name="descripcion" fullWidth multiline minRows={3}
                    value={datos.descripcion} onChange={actualizarCampo} disabled={enviando} />
                <TextField label="Duración (horas)" name="duracion" type="number" required fullWidth
                    slotProps={{ htmlInput: { min: 1, step: 1 } }}
                    value={datos.duracion} onChange={actualizarCampo} disabled={enviando} />
                {error && <Alert severity="error" sx={{ gridColumn: "1 / -1" }}>{error}</Alert>}
                <Stack direction={{ xs: "column", sm: "row" }} spacing={1}
                    sx={{ gridColumn: "1 / -1", justifyContent: "flex-end" }}>
                    {editando && <Button variant="outlined" type="button" onClick={onCancelar} disabled={enviando}>Cancelar</Button>}
                    <Button variant="contained" type="submit" disabled={enviando}>
                        {enviando ? "Guardando…" : editando ? "Guardar cambios" : "Registrar curso"}
                    </Button>
                </Stack>
            </Box>
        </Paper>
    )
}
