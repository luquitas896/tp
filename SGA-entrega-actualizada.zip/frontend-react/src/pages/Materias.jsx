import { useState } from "react"
import Alert from "@mui/material/Alert"
import FormularioMateria from "../components/FormularioMateria"
import { ListaMaterias } from "../components/ListaMaterias"
import { useAuth } from "../context/useAuth"

export default function Materias() {
    const [actualizar, setActualizar] = useState(0)
    const [materiaEditar, setMateriaEditar] = useState(null)
    const [mensaje, setMensaje] = useState("")
    const { usuario } = useAuth()
    const esAdmin = usuario?.rol === "admin"

    function materiaGuardada(mensajeOperacion = "") {
        setActualizar(valor => valor + 1)
        setMateriaEditar(null)
        setMensaje(mensajeOperacion)
    }

    return (
        <>
            {mensaje && <Alert severity="success" role="status" sx={{ mb: 3 }}>{mensaje}</Alert>}
            {esAdmin && <FormularioMateria
                key={materiaEditar?.codigo ?? "nueva"}
                materiaEditar={materiaEditar}
                onMateriaGuardada={materiaGuardada}
                onCancelar={() => {
                    setMensaje("")
                    setMateriaEditar(null)
                }}
            />}
            <ListaMaterias
                actualizar={actualizar}
                onMateriaGuardada={materiaGuardada}
                onEditarMateria={setMateriaEditar}
            />
        </>
    )
}
