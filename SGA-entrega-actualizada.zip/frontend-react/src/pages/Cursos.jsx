import { useState } from "react"
import { Alert, Box, Stack, Typography } from "@mui/material"
import FormularioCurso from "../components/FormularioCurso"
import ListaCursos from "../components/ListaCursos"
import { useAuth } from "../context/useAuth"

export default function Cursos() {
    // Cambia cada vez que hay que volver a pedir el listado al backend
    const [version, setVersion] = useState(0)
    // Curso seleccionado con el botón Editar (null = formulario en modo "nuevo")
    const [seleccionado, setSeleccionado] = useState(null)
    const [aviso, setAviso] = useState("")
    const { usuario } = useAuth()
    const puedeEditar = usuario?.rol === "admin"

    // Se ejecuta después de registrar, modificar o eliminar
    function alTerminarOperacion(texto = "") {
        setVersion(v => v + 1)
        setSeleccionado(null)
        setAviso(texto)
    }

    function cancelarEdicion() {
        setAviso("")
        setSeleccionado(null)
    }

    return (
        <Stack spacing={3}>
            <Box>
                <Typography variant="overline" color="primary" sx={{ fontWeight: 700, letterSpacing: 2 }}>Gestión académica</Typography>
                <Typography component="h1" variant="h3" sx={{ fontWeight: 800, mb: 1 }}>Cursos</Typography>
                <Typography color="text.secondary">Consultá la oferta de cursos, sus contenidos y duración.</Typography>
            </Box>
            {aviso && <Alert severity="success" role="status" sx={{ mb: 3 }}>{aviso}</Alert>}

            <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: puedeEditar ? "minmax(280px, 360px) minmax(0, 1fr)" : "1fr" }, gap: 3, alignItems: "start" }}>
                {puedeEditar && (
                    <FormularioCurso
                        key={seleccionado?.codigo ?? "nuevo"}
                        curso={seleccionado}
                        onGuardado={alTerminarOperacion}
                        onCancelar={cancelarEdicion}
                    />
                )}

                <ListaCursos
                    version={version}
                    onEditar={setSeleccionado}
                    onEliminado={alTerminarOperacion}
                />
            </Box>
        </Stack>
    )
}
