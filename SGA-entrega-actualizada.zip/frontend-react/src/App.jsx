import Alumnos from "./pages/Alumnos"
import {FAQ} from "./pages/FAQ"
import {Routes, Route, Navigate} from "react-router-dom"
import LayoutPpal from "./layouts/LayoutPpal"
import Inicio from "./pages/Inicio"
import Docentes from "./pages/Docentes"
import Materias from "./pages/Materias"
import Login from "./pages/Login"
import RutaProtegida from "./components/RutaProtegida"
import Cursos from "./pages/Cursos"   // <-- NUEVO


function App()
{

return (
   <Routes>
    <Route path="/login" element={<Login />} />
    <Route element={<RutaProtegida />}>
      <Route path="/" element={<LayoutPpal />}>
        <Route index element={<Inicio />} />
        <Route path="alumnos" element={<Alumnos />} />
        <Route path="docentes" element={<Docentes />} />
        <Route path="materias" element={<Materias />} />
        <Route path="cursos" element={<Cursos />} />   {/* <-- NUEVO: se renderiza en el <Outlet /> de LayoutPpal */}
        <Route path="ayuda" element={<FAQ />} />
      </Route>
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
  )
}
export default App
