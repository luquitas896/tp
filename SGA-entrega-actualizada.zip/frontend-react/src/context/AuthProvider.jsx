import { useEffect, useState } from "react"
import { AuthContext } from "./AuthContext"
import API_URL from "../config/api"

function leerUsuarioGuardado() {
    try {
        const usuario = localStorage.getItem("usuario")
        return usuario ? JSON.parse(usuario) : null
    } catch (error) {
        localStorage.removeItem("usuario")
        return null
    }
}

const AuthProvider = ({ children }) => {
    const [token, setToken] = useState(() => localStorage.getItem("token"))
    const [cargando, setCargando] = useState(true)
    const [usuario, setUsuario] = useState(() => leerUsuarioGuardado())

    const cerrarSesion = () => {
        localStorage.removeItem("token")
        localStorage.removeItem("usuario")
        setToken(null)
        setUsuario(null)
    }

    useEffect(() => {
        const verificarSesion = async () => {
            const tokenGuardado = localStorage.getItem("token")
            const usuarioGuardado = leerUsuarioGuardado()

            if (!tokenGuardado || !usuarioGuardado) {
                cerrarSesion()
                setCargando(false)
                return
            }

            try {
                const respuesta = await fetch(`${API_URL}/alumnos`, {
                    headers: { Authorization: `Bearer ${tokenGuardado}` }
                })

                if (!respuesta.ok) {
                    throw new Error("Sesión inválida")
                }

                setToken(tokenGuardado)
                setUsuario(usuarioGuardado)
            } catch (error) {
                console.error("Error al verificar la sesión:", error)
                cerrarSesion()
            } finally {
                setCargando(false)
            }
        }

        verificarSesion()
    }, [])

    return (
        <AuthContext.Provider value={{ token, setToken, cerrarSesion, cargando, usuario, setUsuario }}>
            {children}
        </AuthContext.Provider>
    )
}

export default AuthProvider
